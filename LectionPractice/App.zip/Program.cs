﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;

class AweseomeException : Exception
{
    public AweseomeException(int number) : base(String.Format("My first exception is awesome!!!")) { }
}

class Program
{
    static void Main()
    {
        try
        {
            while (true)
            {
                var input = int.Parse(ReadLine());
                if (input < 0)
                    throw new AweseomeException(input);
                WriteLine(input);
            }
        }
        catch (AweseomeException e)
        {
            WriteLine(e.Message);
        }
    }
}