<?php
/**
 * Created by IntelliJ IDEA.
 * User: brain
 * Date: 19.07.17
 * Time: 23:35
 */

namespace CalculatorBundle\Entity;

class Calculator{

    /**
     * @var float
     */
    private $leftOperand;

    /**
     * @var float
     */
    private $rightOperand;

    /**
     * @var string
     */
    private $operator;


    /*************************** OPERATOR GETTER & SETTER ***********************************/

    /**
     * Get operator
     *
     * @return float
     */
    public function getOperator()
    {
        return $this->operator;
    }

    /**
     * Set the operator
     *
     * @param string $operator
     *
     * @return Calculator
     */
    // NOTE: The setter takes the data, sets it and RETURNS the object itself.
    public function setOperator($operator)
    {
        $this->operator = $operator;

        return $this;
    }

    /**************************************************************************************/

    /****************************** RIGHT OPERAND GETTER & SETTER *************************/

    /**
     * Get right operand
     *
     * @return float
     */
    public function getRightOperand(): float
    {
        return $this->rightOperand??0;
    }

    /**
     * Set right operand
     *
     * @param float $rightOperand
     *
     * @return Calculator
     */
    // NOTE: The setter takes the data, sets it and RETURNS the object itself.
    public function setRightOperand(float $rightOperand)
    {
        $this->rightOperand = $rightOperand;

        return $this;
    }

    /************************************************************************************/

    /***************************** LEFT OPERAND GETTER & SETTER ************************/

    /**
     * Get left operand
     *
     * @return float
     */
    public function getLeftOperand(): float
    {
        return $this->leftOperand??0;
    }

    /**
     *Set left operand
     *
     * @param float $leftOperand
     *
     * @return Calculator
     */
    // NOTE: The setter takes the data, sets it and RETURNS the object itself.
    public function setLeftOperand(float $leftOperand)
    {
        $this->leftOperand = $leftOperand;

        return $this;
    }

    /*********************************************************************************/

    // PROCEED: Controller/CalculatorController...
}