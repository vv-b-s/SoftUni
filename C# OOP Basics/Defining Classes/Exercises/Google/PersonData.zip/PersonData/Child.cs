﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Google.PersonData
{
    public class Child : Parent
    {
        public Child(string name, string birthday) : base(name, birthday) { }
    }
}
